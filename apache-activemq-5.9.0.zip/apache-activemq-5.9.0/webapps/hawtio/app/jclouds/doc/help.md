### jclouds

This plugin works with [jclouds](http://jclouds.org/) so you can view your cloud resources and start, stop and restart your compute nodes.