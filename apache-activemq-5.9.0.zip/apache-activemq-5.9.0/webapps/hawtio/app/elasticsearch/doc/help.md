### Elasticsearch

This hawtio plugin allows to connect to a ElasticSearch (http://www.elasticsearch.org/) server running on a machine (e.g : localhost:9200) and can be query to retrieve
documents from indices. By default the 'index Sample Docs' will populate an indice 'twitter' and create documents of type 'tweet'.

Remarks :

  - Elasticsearch server must be started locally using command './elasticsearch -f'
  - By default values can be changed in the config.js file

