### Developer Guide

[hawtio](http://hawt.io/) is designed around a large suite of [plugins](http://hawt.io/plugins/index.html) and active [community](http://hawt.io/community/index.html) and we love [contributions](http://hawt.io/contributing/index.html)!

For more background on how to build your own plugins for **hawtio** check out the [developer help](http://hawt.io/developers/index.html)

**hawtio** also includes a number of developer focussed plugins to help developers create even better plugins.

Click on the links on the left to see more!

