### Infinispan

This plugin works with [Infinispan](http://infinispan.org/) so you can visualise the caches you have and see their metrics.